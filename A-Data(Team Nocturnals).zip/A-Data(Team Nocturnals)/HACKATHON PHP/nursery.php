<?php
session_start();
require_once 'Login/class.user.php';
$user_home = new USER();

if(!$user_home->is_logged_in())
{
  $user_home->redirect('Home.php');
}

$stmt = $user_home->runQuery("SELECT * FROM tblemployee WHERE EmpID=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSession']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);

?>



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
<title></title>

<style>

body{
  margin: 0;
  font-family: Montserrat, sans-serif;
  background-image: url(images/bg1.png);
  background-size: cover;
}

.employee{
  display: flex;
  justify-content: center;
  align-items: center
}

.employee2{
  margin-top: 4vw;
  display: flex;
  justify-content: center;
  align-items: center
}

.employee3{
  display: flex;
  justify-content: center;
  align-items: center
}

.topnav {
  overflow: hidden;
  background-color: #00AEEE;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #abcdef;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #023a62;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #abcdef;
  color: white;
}

.dropdown-content a:hover {
    background-color: #abcdef;
    color: white;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
.datafarm p, input{
  font-size: 1.5vw;
  font-family: Montserrat, sans-serif;
  font-weight: 400;
}
</style>
</head>
<body>

<div class="topnav" id="myTopnav">

<a><img src="images/logo6.png" style="width: 5vw; height: 1.4vw;"></a>

    <a href="#" style="font-family: Montserrat, sans-serif; font-weight: 800; font-size: 1.1em; color: white;">Real-Time Check</a> 
    
  <div class="dropdown">
    <button class="dropbtn" style="font-family: Montserrat, sans-serif; font-weight: 800; font-size: 1.1em;">Harvest Recording
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content" style="font-family: Montserrat, sans-serif; font-weight: 400; font-size: 1.1em;">
      <a href="breeding.php">Breeding</a>
      <a href="nursery.php">Nursery</a>
      <a href="growing.php">Growing</a>
      <a href="barn.php">Barn</a>
    </div>
  </div> 

  <div class="dropdown">
    <button class="dropbtn" style="font-family: Montserrat, sans-serif; font-weight: 800; font-size: 1.1em;">Settings
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content" style="font-family: Montserrat, sans-serif; font-weight: 400; font-size: 1.1em; width: 1vw; font-size: 2vw;">
      <a href="Login/logout.php">Logout</a>
      
    </div>
  </div> 
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>

</div>


<div class="datafarm" style="padding-left: 2vw;">
<h1 style="color: #00AEEE; font-size: 3.4vw;">Nursery</h1>

<form method="POST">
<p style="font-family: Montserrat, sans-serif; font-weight: 400;">Piglet Number: <input type="textbox" onkeypress="isInputNumber(event)" name="pigNumber" required></p>
<p style="font-family: Montserrat, sans-serif; font-weight: 400;">Date of Birth: <input type="date" name="dateofbreed" required></p>
<p style="font-family: Montserrat, sans-serif; font-weight: 400;">Breed: <input type="textbox" name="breed" required></p>
<p style="font-family: Montserrat, sans-serif; font-weight: 400;">Birth Weight: <input type="textbox" onkeypress="isInputNumber(event)" name="weight" required></p>
<p style="font-family: Montserrat, sans-serif; font-weight: 400;">Starting breast feed date: <input type="date" name="startbreastfeed" required></p>
<p style="font-family: Montserrat, sans-serif; font-weight: 400;">Ending breast feed date: <input type="date" name="endbreastfeed" required></p>
<p style="font-family: Montserrat, sans-serif; font-weight: 400;">Amount of feeds per day (per kg.): <input type="textbox" onkeypress="isInputNumber(event)" name="feeds" required></p>
<p style="font-family: Montserrat, sans-serif; font-weight: 400;">Injected Medicines: <input type="textbox" name="med" required></p>
<p style="font-family: Montserrat, sans-serif; font-weight: 400;">Injection Date: <input type="date" name="injectdate" required></p>
<p style="font-family: Montserrat, sans-serif; font-weight: 400;">Barn Number: <input type="textbox" name="bar" onkeypress="isInputNumber(event)" required></p>

<button type="submit" name="submit" class="btn btn-lg btn-primary" style="color: white; background-color: #00AEEE; width: 12vw; height: 4vw; font-size: 1.5vw; font-family: Montserrat, sans-serif; font-weight: 800;">SUBMIT</button>
</div>
</form>
<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}

function isInputNumber(evt){
                
                var ch = String.fromCharCode(evt.which);
                
                if(!(/[0-9]/.test(ch))){
                    evt.preventDefault();
                }
            }

</script>


</body>
</html>

<?php

if(isset($_POST['submit']))
{
  $pignumber = $_POST['pigNumber'];
  $dateofbreed = $_POST['dateofbreed'];
  $breed = $_POST['breed'];
  $weight = $_POST['weight'];
  $sbreastfeed = $_POST['startbreastfeed'];
  $ebreastfeed = $_POST['endbreastfeed'];

  $feeds = $_POST['feeds'];
  $med = $_POST['med'];
  $idate = $_POST['injectdate'];
  $bar = $_POST['bar'];


  $link = mysqli_connect("localhost", "u396535769_hack","123456789","u396535769_hack");

  mysqli_query($link,"INSERT INTO `tblnursery`
(`PigletNumber`, `DateofBirth`, `TypeofBreed`, `Weight`, `StartofBreastFeeding`, `EndofBreastFeeding`, `FeedsPerDay`, `InjectedMedicine`, `DateofInjection`, `BarnNumber`) VALUES 
('$pignumber','$dateofbreed','$breed','$weight','$sbreastfeed','$ebreastfeed','$feeds','$med','$idate','$bar')");



}
?>
