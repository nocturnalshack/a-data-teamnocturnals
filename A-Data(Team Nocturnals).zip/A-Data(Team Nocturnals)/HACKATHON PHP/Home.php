<?php

$connect = mysqli_connect("localhost", "u396535769_hack","123456789","u396535769_hack");

session_start();
require_once 'Login/class.user.php';
$user_login = new USER();

if($user_login->is_logged_in()!="")
{
  $user_login->redirect('employee.php');
}
 
if(isset($_POST['btn-login']))
{
  $email = trim($_POST['txtemail']);
  $upass = trim($_POST['txtupass']);

  if($user_login->login($email,$upass))
  {
    $user_login->redirect('employee.php');
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Data</title>
</head>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

<style>

body{
  background-image: url(images/bgmain.jpg);
  background-size: cover;
  background-repeat: no-repeat;
  height: 100%;
  background-position: center;
  background-attachment: fixed;
}

#logo2{
  display: flex;
    justify-content: center;
    align-items: center;
}

#login{
  font-family: Montserrat, sans-serif;
  font-weight: 600;
  background-size: 100%;
  background-position: center;
}

#userlogin{
  display: flex;
    justify-content: center;
    align-items: center;
}

.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

.modal-content {
    background-color: #E9E9E9;
    margin: auto;
    padding: 20px;
    border: 5px solid #00AEEE;
    width: 90vw;
    font-family: Montserrat, sans-serif;
    font-size: 1.6vw;
}

.close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}

</style>

<!-- #00AEEE; MAIN COLOR -->

<body>

<div id="logo2">
<img src="images/logo5.png" style="width: 15vw; height: 15vw;">
</div>

<center>
<div class="container">
  <div class="col-sm-12">
         <?php

   $query = "SELECT * FROM `tblfarm1`";
   $connect = mysqli_connect("localhost", "u396535769_hack","123456789","u396535769_hack");

   $result = mysqli_query($connect,$query);

    while ($row = mysqli_fetch_array($result)) { ?>

    <div class="col-sm-4" style="background-color: #00AEEE;  height: 25vw;">
<br>
        <img src="images/temp.png" style="width: 15vw; height: 15vw;">
        <br></br>
      <label><?php echo $row["Temperature"]; ?></label>
    </div>

    <div class="col-sm-4" style="background-color: #0094CA; height: 25vw;">
<br>
        <img src="images/hum.png" style=" width: 15vw; height: 15vw;">
        <br></br>
      <label><?php echo $row["Humidity"]; ?></label>
    </div>

    <div class="col-sm-4" style="background-color: #00719B; height: 25vw;">
 <br>       
        <img src="images/gas.png" style="width: 15vw; height: 15vw;">
        <br></br>
      <label><?php echo $row["Gas"]; ?></label>
    </div>

  </div>
  <?php } ?>
</div>
</center>

<center>
<div class="container" id="userlogin">
  
    <form method="POST">
  <div class="login" style="background-image: url(images/bguser.jpg); height: 50%; width: 86.7vw; border: 5px solid #FFFFFF; background-size: 100%; background-attachment: fixed; background-position: center;">
  
  <h1 style="font-family: 'Montserrat', sans-serif; font-weight: 700; font-size: 2.9vw; color: #008FC5;">USERNAME:</h1>
  <input type="text" name="txtemail" style="width: 18.5vw; height: 3.5vw; font-size: 1.8vw; font-family: 'Montserrat', sans-serif; font-weight: 400;">
  <br>
  <br>
  <h1 style="font-family: 'Montserrat', sans-serif; font-weight: 700; font-size: 2.9vw; color: #008FC5;">PASSWORD:</h1>
  <input type="text" name="txtupass" style="width: 18.5vw; height: 3.5vw; font-size: 1.8vw; font-family: 'Montserrat', sans-serif; font-weight: 400;">
  <br>
  <br>
  <p>

  
    <a id="myBtn" style="width: 8vw; color: white; background-color: #008FC5; font-size: 1vw; font-family: Montserrat, sans-serif; font-weight: 800; cursor:pointer;text-decoration: none;" >SIGN UP</a>
    
  <input type="submit" name="btn-login" style="width: 8vw; color: white; background-color: #008FC5; margin-left: 2.1vw; font-size: 1vw; font-family: Montserrat, sans-serif; font-weight: 800;" value="LOGIN">

  </p>

  <br>

    </div>
</form>
</div>
</center>

<div class="container">



<div id="myModal" class="modal">


  <div class="modal-content" style="color: #00AEEE;">
    <span class="close" style="color: black; font-size: 4vw;">&times;</span>

    <div id="logo2">
  <img src="images/logo.png" style="width: 15vw; height: 15vw; margin-left: 2vw">
  </div>

      <br>
    <div class="container">
         <div class="col-sm-12">

         <div class="col-sm-6">
            <form method="POST">
            <label><b>First Name:</b></label>
            <br>
          <input type ="text" class="input-block-level" placeholder="First Name" name="txtname" style="color: black;" required>

          <br><br>

          <label><b>Last Name:</b></label>
          <br>
          <input type ="text" class="input-block-level" placeholder="Last Name" name="txtlast" style="color: black;" required> 

          <br><br>

          <label><b>Middle Name:</b></label>
          <br>
          <input type ="text" class="input-block-level" placeholder="Middle Name" name="txtmiddle" style="color: black;" required>

          <br><br>
   
          <label><b>Email:</b></label>
          <br>
          <input type ="email" class="input-block-level" placeholder="Email" name="txtemail" style="color: black;" required>

          <br><br>

          <label><b>Contact No.:</b></label>
          <br>
          <input type ="text" class="input-block-level" onkeypress="isInputNumber(event)" maxlength="10" placeholder="Enter Contact No." name="txtno" style="color: black;" required>
          
          <br><br>

            </div>

            <div class="col-sm-6">

            <label><b>Birthday</b></label>
            <br>
            <input type="date" class="input-block-level" placeholder="Enter Birthday" name="txtdate" id="txtdate" style="color: black;" required>
            <script>
var today = new Date();

var today2 = new Date();

var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear()-19;

var dd2 = today2.getDate();
var mm2 = today2.getMonth()+1; //January is 0!
var yyyy2 = today2.getFullYear()-99;


 if(dd<10){
        dd='0'+dd
    } 
    if(mm<10)
    {
        mm='0'+mm
    } 


 if(dd2<10){
        dd2='0'+dd2
    } 
    if(mm2<10)
    {
        mm2='0'+mm2
    } 


today = yyyy+'-'+mm+'-'+dd;

today2 = yyyy2+'-'+mm2+'-'+dd2;

document.getElementById("txtdate").setAttribute("max", today);

document.getElementById("txtdate").setAttribute("min", today2);



            </script>
            <br><br>

            <label><b>Username:</b></label>
            <br>
            <input type ="text" class="input-block-level" placeholder="Enter Username" name="txtuser" style="color: black;" required>
            
            <br><br>

            <label><b>Password:</b></label>
            <br>
            <input type ="password" class="input-block-level" placeholder="Enter Password" pattern=".{6,}" name="password" id="password" style="color: black;" required>
            
            <br><br>

            <label><b>Repeat Password:</b></label>
            <br>

        <input type ="password" class="input-block-level" placeholder="Repeat Password" name="psw-repeat" id="confirm"  style="color: black;" required onChange="checkPasswordMatch();">
            <div class="registrationFormAlert" name="checkpass" style="color: red" id="divCheckPasswordMatch"></div>

            <br><br>

            </div>

            </div>

            </div>
<center>
          <button type="submit" name="submit" class="submitbtn" style="font-family: Montserrat, sans-serif; font-weight: 800; background-color: #00AEEE; color: white; width: 15vw; height: 4.5vw; ">SUBMIT</button>      
    
</center>
   </div>
   </form>
</div>  
<?php
if(isset($_POST['submit']))
{
    $First = $_POST['txtname'];
    $Last = $_POST['txtlast'];
    $Middle = $_POST['txtmiddle'];
    $email = $_POST['txtemail'];
    $ContactNo = $_POST['txtno'];
    $Birthday = $_POST['txtdate'];
    $user = $_POST['txtuser'];
    $password = $_POST['password'];

    $contno = '63'.$ContactNo;

    $link = mysqli_connect ("localhost", "u396535769_hack","123456789","u396535769_hack");
    
        $query1 = mysqli_query($link,"SELECT * FROM `tblemployee` WHERE `Username`='$user'");

        if(mysqli_num_rows($query1) > 0 )  
        { 
            echo '<script>alert("SAME USERNAME")</script>'; 
        }
        else
        {
            

            mysqli_query($link, "INSERT INTO `tblemployee`
                (`FirstName`, `LastName`, `MiddleName`, `Email`, `ContactNo`, `Birthday`, `Username`, `Password`) VALUES
                ('$First','$Last','$Middle','$email','$contno','$Birthday','$user','$password')");

            echo '<script>alert("Successfully Inserted")</script>'; 
        }
}
?>
<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}


function checkPasswordMatch() {
    var password = $("#password").val();
    var confirmPassword = $("#confirm").val();
    var button = $('#btn-signup');

    if(!password && !confirmPassword)
    {

    }
    else if (password != confirmPassword){
        $("#divCheckPasswordMatch").html("Password do not match!");
        document.getElementById("divCheckPasswordMatch").style.color = "red";
      }

    else{
        $("#divCheckPasswordMatch").html("Password match.");
        document.getElementById("divCheckPasswordMatch").style.color = "green";}
}

$(document).ready(function () {
   $("#password, #confirm").keyup(checkPasswordMatch);
});
 function isInputNumber(evt){
                
                var ch = String.fromCharCode(evt.which);
                
                if(!(/[0-9]/.test(ch))){
                    evt.preventDefault();
                }
            }

</script>
</div>
</body>
</html>