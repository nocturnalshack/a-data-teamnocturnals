
<!doctype html>
<html lang="en">
<head>

</head>

<body>

<?php
                            $temperature = $_GET['T'];
                            $humid = $_GET['H'];
                            $ammon = $_GET['A'];

          $link = mysqli_connect ("localhost", "u396535769_hack","123456789","u396535769_hack");

    mysqli_query($link,"UPDATE `tblfarm1` SET `Temperature`='$temperature',`Humidity`='$humid',`Gas`='$ammon' WHERE `RealTimeID` = '1'");

  ?>

</body>

</html>