﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WMPLib;
using AxWMPLib;
using MySql.Data.MySqlClient;
using System.Reflection;
using System.Diagnostics;
using Tulpep.NotificationWindow;
using System.Net;

namespace HACKATONN
{
    public partial class FARM1 : Form
    {
        public FARM1()
        {
            InitializeComponent();
        }
        String mysqlAddress = "Server = auth-db165.hostinger.ph;port = 3306; database = u396535769_hack;Username = u396535769_hack ; pwd=123456789";
        public void temperature()
        {
            string query = "select Temperature from tblfarm1";
            MySqlConnection connectt = new MySqlConnection(mysqlAddress);
            MySqlCommand mySqlCommand = new MySqlCommand(query, connectt);
            connectt.Open();
            MySqlDataReader read = mySqlCommand.ExecuteReader();
            if (read.Read())
            {
                label1.Text = read[0].ToString();
                connectt.Close();
            }
            
        }
        public void humidity()
        {
            string query = "select Humidity from tblfarm1";
            MySqlConnection connectt = new MySqlConnection(mysqlAddress);
            MySqlCommand mySqlCommand = new MySqlCommand(query, connectt);
            connectt.Open();
            MySqlDataReader read = mySqlCommand.ExecuteReader();
            if (read.Read())
            {
                label13.Text = read[0].ToString();
                connectt.Close();
            }

        }
        public void gas()
        {
            string query = "select Gas from tblfarm1";
            MySqlConnection connectt = new MySqlConnection(mysqlAddress);
            MySqlCommand mySqlCommand = new MySqlCommand(query, connectt);
            connectt.Open();
            MySqlDataReader read = mySqlCommand.ExecuteReader();
            if (read.Read())
            {
                label16.Text = read[0].ToString();
                connectt.Close();
            }

        }
        public void temperaturemonitoringfarm1()
        {
            Random rnd = new Random();
            int aa = rnd.Next(0, 1000);
            MySqlConnection cnn = new MySqlConnection(mysqlAddress);
            cnn.Open();
            MySqlCommand cmdinsert;
            cmdinsert = cnn.CreateCommand();
            cmdinsert.CommandText = "Insert into tbltemperature(ID,Temperature,TempDate,TempTime,TempFarm) values(@ID,@Temp,@Date,@Time,@Farm)";
            cmdinsert.Parameters.AddWithValue("@ID", aa.ToString());
            cmdinsert.Parameters.AddWithValue("@Temp",label1.Text);
            cmdinsert.Parameters.AddWithValue("@Date", System.DateTime.Now.ToLongDateString());
            cmdinsert.Parameters.AddWithValue("@Time", System.DateTime.Now.ToLongTimeString());
            cmdinsert.Parameters.AddWithValue("@Farm", label4.Text);
            cmdinsert.ExecuteNonQuery();
            cnn.Close();
        }
        public void humiditymonitoringfarm1()
        {
            Random rnd = new Random();
            int aa = rnd.Next(0, 1000);
            MySqlConnection cnn = new MySqlConnection(mysqlAddress);
            cnn.Open();
            MySqlCommand cmdinsert;
            cmdinsert = cnn.CreateCommand();
            cmdinsert.CommandText = "Insert into tblhumidity(ID,Humidity,HumDate,HumTime,HumFarm) values(@ID,@Temp,@Date,@Time,@Farm)";
            cmdinsert.Parameters.AddWithValue("@ID", aa.ToString());
            cmdinsert.Parameters.AddWithValue("@Temp", label13.Text);
            cmdinsert.Parameters.AddWithValue("@Date", System.DateTime.Now.ToLongDateString());
            cmdinsert.Parameters.AddWithValue("@Time", System.DateTime.Now.ToLongTimeString());
            cmdinsert.Parameters.AddWithValue("@Farm", label4.Text);
            cmdinsert.ExecuteNonQuery();
            cnn.Close();
        }
        public void gasmonitoringfarm1()
        {
            Random rnd = new Random();
            int aa = rnd.Next(0, 1000);
            MySqlConnection cnn = new MySqlConnection(mysqlAddress);
            cnn.Open();
            MySqlCommand cmdinsert;
            cmdinsert = cnn.CreateCommand();
            cmdinsert.CommandText = "Insert into tblhumidity(ID,Gas,GasDate,GasTime,GasFarm) values(@ID,@Temp,@Date,@Time,@Farm)";
            cmdinsert.Parameters.AddWithValue("@ID", aa.ToString());
            cmdinsert.Parameters.AddWithValue("@Temp", label13.Text);
            cmdinsert.Parameters.AddWithValue("@Date", System.DateTime.Now.ToLongDateString());
            cmdinsert.Parameters.AddWithValue("@Time", System.DateTime.Now.ToLongTimeString());
            cmdinsert.Parameters.AddWithValue("@Farm", label4.Text);
            cmdinsert.ExecuteNonQuery();
            cnn.Close();
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FARM1_Load(object sender, EventArgs e)
        {
            timer1.Start();
            timer2.Start();
            timer3.Start();
        }

        private void bunifuDropdown1_onItemSelected(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            temperature();
        }

        private void label1_TextChanged(object sender, EventArgs e)
        {
            int aa = Convert.ToInt32(label1.Text);
            if (aa < 15)
            {
                temperaturemonitoringfarm1();
                PopupNotifier popup = new PopupNotifier();
                popup.BorderColor = Color.LightGray;
                popup.BodyColor = Color.Black;
                popup.ImageSize = new Size(100, 70);
                popup.ImagePadding = new Padding(10, 10, 0, 0);
                popup.TitleText = "TEMPERATURE STATUS NOTICE";
                popup.TitleFont = new Font("Times New Roman", 14);
                popup.TitleColor = Color.Red;
                popup.TitlePadding = new Padding(0, 10, 20, 0);
                popup.ContentFont = new Font("Times New Roman", 10);
                popup.ContentPadding = new Padding(30, 5, 5, 5);
                popup.ContentColor = Color.Tomato;
                popup.ContentText = "TEMPERATURE IS GETTING TOO HIGH!";
                popup.Popup();
                String result;
                string apiKey = "UMqX6U9a2Zo-hYU68O514j4Aea251hARQ35diaGurj";
                string numbers = "639971574867"; // in a comma seperated list
                string message = "TEMPERATURE IS GETTING TOO LOW DO SOME ACTION!";
                string send = "STI";
                String url = "https://api.txtlocal.com/send/?apikey=" + apiKey + "&numbers=" + numbers + "&message=" + message + "&sender=" + send;
                //refer to parameters to complete correct url strin
                StreamWriter myWriter = null;
                HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);
                objRequest.Method = "POST";
                objRequest.ContentLength = Encoding.UTF8.GetByteCount(url);
                objRequest.ContentType = "application/x-www-form-urlencoded";
                try
                {
                    myWriter = new StreamWriter(objRequest.GetRequestStream());
                    myWriter.Write(url);
                }
                catch (Exception ee)
                {
                    //return e.Message;
                    MessageBox.Show(null, "the error is" + ee.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                finally
                {
                    myWriter.Close();
                }

                HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
                using (StreamReader sr = new StreamReader(objResponse.GetResponseStream()))
                {
                    result = sr.ReadToEnd();
                    // Close and clean up the StreamReader
                    sr.Close();
                }
                Hypothermia h = new Hypothermia();
                h.Show();
                //return result;
            }
            else if (aa > 40)
            {
                temperaturemonitoringfarm1();
                PopupNotifier popup = new PopupNotifier();
                popup.BorderColor = Color.LightGray;
                popup.BodyColor = Color.Black;
                popup.ImageSize = new Size(100, 70);
                popup.ImagePadding = new Padding(10, 10, 0, 0);
                popup.TitleText = "TEMPERATURE STATUS NOTICE";
                popup.TitleFont = new Font("Times New Roman", 14);
                popup.TitleColor = Color.Red;
                popup.TitlePadding = new Padding(0, 10, 20, 0);
                popup.ContentFont = new Font("Times New Roman", 10);
                popup.ContentPadding = new Padding(30, 5, 5, 5);
                popup.ContentColor = Color.Tomato;
                popup.ContentText = "TEMPERATURE IS GETTING TOO HIGH!";
                popup.Popup();
                String result;
                string apiKey = "UMqX6U9a2Zo-hYU68O514j4Aea251hARQ35diaGurj";
                string numbers = "639971574867"; // in a comma seperated list
                string message = "TEMPERATURE IS GETTING TOO HIGH DO SOME ACTION!";
                string send = "STI";

                String url = "https://api.txtlocal.com/send/?apikey=" + apiKey + "&numbers=" + numbers + "&message=" + message + "&sender=" + send;
                //refer to parameters to complete correct url string

                StreamWriter myWriter = null;
                HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);

                objRequest.Method = "POST";
                objRequest.ContentLength = Encoding.UTF8.GetByteCount(url);
                objRequest.ContentType = "application/x-www-form-urlencoded";
                try
                {
                    myWriter = new StreamWriter(objRequest.GetRequestStream());
                    myWriter.Write(url);
                }
                catch (Exception ee)
                {
                    //return e.Message;
                    MessageBox.Show(null, "the error is" + ee.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                finally
                {
                    myWriter.Close();
                }

                HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
                using (StreamReader sr = new StreamReader(objResponse.GetResponseStream()))
                {
                    result = sr.ReadToEnd();
                    // Close and clean up the StreamReader
                    sr.Close();
                }
                //return result;
                Fever f = new Fever();
                f.Show();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            humidity();
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            gas();
        }

        private void label13_TextChanged(object sender, EventArgs e)
        {
            int aa = Convert.ToInt32(label13.Text);
            if (aa < 20)
            {
          
                PopupNotifier popup = new PopupNotifier();
                popup.BorderColor = Color.LightGray;
                popup.BodyColor = Color.Black;
                popup.ImageSize = new Size(100, 70);
                popup.ImagePadding = new Padding(10, 10, 0, 0);
                popup.TitleText = "HUMIDITY STATUS NOTICE";
                popup.TitleFont = new Font("Times New Roman", 14);
                popup.TitleColor = Color.Red;
                popup.TitlePadding = new Padding(0, 10, 20, 0);
                popup.ContentFont = new Font("Times New Roman", 10);
                popup.ContentPadding = new Padding(30, 5, 5, 5);
                popup.ContentColor = Color.Tomato;
                popup.ContentText = "HUMIDITY IS GETTING TOO LOW!";
                popup.Popup();
                String result;
                string apiKey = "UMqX6U9a2Zo-hYU68O514j4Aea251hARQ35diaGurj";
                string numbers = "639971574867"; // in a comma seperated list
                string message = "HUMIDITY IS GETTING TOO LOW DO SOME ACTION!";
                string send = "STI";

                String url = "https://api.txtlocal.com/send/?apikey=" + apiKey + "&numbers=" + numbers + "&message=" + message + "&sender=" + send;
                //refer to parameters to complete correct url string

                StreamWriter myWriter = null;
                HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);

                objRequest.Method = "POST";
                objRequest.ContentLength = Encoding.UTF8.GetByteCount(url);
                objRequest.ContentType = "application/x-www-form-urlencoded";
                try
                {
                    myWriter = new StreamWriter(objRequest.GetRequestStream());
                    myWriter.Write(url);
                }
                catch (Exception ee)
                {
                    //return e.Message;
                    MessageBox.Show(null, "the error is" + ee.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                finally
                {
                    myWriter.Close();
                }

                HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
                using (StreamReader sr = new StreamReader(objResponse.GetResponseStream()))
                {
                    result = sr.ReadToEnd();
                    // Close and clean up the StreamReader
                    sr.Close();
                }
                humiditymonitoringfarm1();
            }
            else if (aa > 40)
            {
                PopupNotifier popup = new PopupNotifier();
                popup.BorderColor = Color.LightGray;
                popup.BodyColor = Color.Black;
                popup.ImageSize = new Size(100, 70);
                popup.ImagePadding = new Padding(10, 10, 0, 0);
                popup.TitleText = "HUMIDITY STATUS NOTICE";
                popup.TitleFont = new Font("Times New Roman", 14);
                popup.TitleColor = Color.Red;
                popup.TitlePadding = new Padding(0, 10, 20, 0);
                popup.ContentFont = new Font("Times New Roman", 10);
                popup.ContentPadding = new Padding(30, 5, 5, 5);
                popup.ContentColor = Color.Tomato;
                popup.ContentText = "HUMIDITY IS GETTING TOO HIGH!";
                popup.Popup();
                String result;
                string apiKey = "UMqX6U9a2Zo-hYU68O514j4Aea251hARQ35diaGurj";
                string numbers = "639971574867"; // in a comma seperated list
                string message = "HUMIDITY IS GETTING TOO HIGH DO SOME ACTION!";
                string send = "STI";

                String url = "https://api.txtlocal.com/send/?apikey=" + apiKey + "&numbers=" + numbers + "&message=" + message + "&sender=" + send;
                //refer to parameters to complete correct url string

                StreamWriter myWriter = null;
                HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);

                objRequest.Method = "POST";
                objRequest.ContentLength = Encoding.UTF8.GetByteCount(url);
                objRequest.ContentType = "application/x-www-form-urlencoded";
                try
                {
                    myWriter = new StreamWriter(objRequest.GetRequestStream());
                    myWriter.Write(url);
                }
                catch (Exception ee)
                {
                    //return e.Message;
                    MessageBox.Show(null, "the error is" + ee.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                finally
                {
                    myWriter.Close();
                }

                HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
                using (StreamReader sr = new StreamReader(objResponse.GetResponseStream()))
                {
                    result = sr.ReadToEnd();
                    // Close and clean up the StreamReader
                    sr.Close();
                }
                humiditymonitoringfarm1();
                //return result;
                MessageBox.Show("PLEASE CHECK THE PINGS AS SOON AS POSSIBLE OR THEY WILL BE SUFFOCATED THAT LEADS TO DEATH!");
            }
        }

        private void label16_TextChanged(object sender, EventArgs e)
        {

            int aa = Convert.ToInt32(label16.Text);
            if (aa < 20)
            {
                gasmonitoringfarm1();
                PopupNotifier popup = new PopupNotifier();
                popup.BorderColor = Color.LightGray;
                popup.BodyColor = Color.Black;
                popup.ImageSize = new Size(100, 70);
                popup.ImagePadding = new Padding(10, 10, 0, 0);
                popup.TitleText = "GAS STATUS NOTICE";
                popup.TitleFont = new Font("Times New Roman", 14);
                popup.TitleColor = Color.Red;
                popup.TitlePadding = new Padding(0, 10, 20, 0);
                popup.ContentFont = new Font("Times New Roman", 10);
                popup.ContentPadding = new Padding(30, 5, 5, 5);
                popup.ContentColor = Color.Tomato;
                popup.ContentText = "GAS IS GETTING TOO LOW!";
                popup.Popup();
                String result;
                string apiKey = "UMqX6U9a2Zo-hYU68O514j4Aea251hARQ35diaGurj";
                string numbers = "639971574867"; // in a comma seperated list
                string message = "GAS IS GETTING TOO LOW DO SOME ACTION!";
                string send = "STI";

                String url = "https://api.txtlocal.com/send/?apikey=" + apiKey + "&numbers=" + numbers + "&message=" + message + "&sender=" + send;
                //refer to parameters to complete correct url string

                StreamWriter myWriter = null;
                HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);

                objRequest.Method = "POST";
                objRequest.ContentLength = Encoding.UTF8.GetByteCount(url);
                objRequest.ContentType = "application/x-www-form-urlencoded";
                try
                {
                    myWriter = new StreamWriter(objRequest.GetRequestStream());
                    myWriter.Write(url);
                }
                catch (Exception ee)
                {
                    //return e.Message;
                    MessageBox.Show(null, "the error is" + ee.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                finally
                {
                    myWriter.Close();
                }

                HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
                using (StreamReader sr = new StreamReader(objResponse.GetResponseStream()))
                {
                    result = sr.ReadToEnd();
                    // Close and clean up the StreamReader
                    sr.Close();
                }
                //return result;

            }
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            timer4.Start();
            timer5.Stop();
            timer6.Stop();
            timer7.Stop();
            MySqlConnection cnn = new MySqlConnection(mysqlAddress);
            cnn.Open();
            try
            {
                MySqlCommand cmddisplay = cnn.CreateCommand();
                cmddisplay.CommandText = "select * from tblbarn";
                MySqlDataAdapter adaptable = new MySqlDataAdapter(cmddisplay);
                DataSet ds = new DataSet();
                adaptable.Fill(ds);
                barn.DataSource = ds.Tables[0].DefaultView;
                barn.AutoResizeColumns();
                cnn.Close();
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (cnn.State == ConnectionState.Open)
                {
                    cnn.Clone();
                }
            }
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            timer4.Stop();
            timer5.Start();
            timer6.Stop();
            timer7.Stop();
            MySqlConnection cnn = new MySqlConnection(mysqlAddress);
            cnn.Open();
            try
            {
                MySqlCommand cmddisplay = cnn.CreateCommand();
                cmddisplay.CommandText = "select * from tblbreeding";
                MySqlDataAdapter adaptable = new MySqlDataAdapter(cmddisplay);
                DataSet ds = new DataSet();
                adaptable.Fill(ds);
                barn.DataSource = ds.Tables[0].DefaultView;
                barn.AutoResizeColumns();
                cnn.Close();
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (cnn.State == ConnectionState.Open)
                {
                    cnn.Clone();
                }
            }
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            timer4.Stop();
            timer5.Stop();
            timer6.Start();
            timer7.Stop();
            MySqlConnection cnn = new MySqlConnection(mysqlAddress);
            cnn.Open();
            try
            {
                MySqlCommand cmddisplay = cnn.CreateCommand();
                cmddisplay.CommandText = "select * from tblnursery";
                MySqlDataAdapter adaptable = new MySqlDataAdapter(cmddisplay);
                DataSet ds = new DataSet();
                adaptable.Fill(ds);
                barn.DataSource = ds.Tables[0].DefaultView;
                barn.AutoResizeColumns();
                cnn.Close();
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (cnn.State == ConnectionState.Open)
                {
                    cnn.Clone();
                }
            }
        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            timer4.Stop();
            timer5.Stop();
            timer6.Stop();
            timer7.Start();
            MySqlConnection cnn = new MySqlConnection(mysqlAddress);
            cnn.Open();
            try
            {
                MySqlCommand cmddisplay = cnn.CreateCommand();
                cmddisplay.CommandText = "select * from tblgrowing";
                MySqlDataAdapter adaptable = new MySqlDataAdapter(cmddisplay);
                DataSet ds = new DataSet();
                adaptable.Fill(ds);
                barn.DataSource = ds.Tables[0].DefaultView;
                barn.AutoResizeColumns();
                cnn.Close();
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (cnn.State == ConnectionState.Open)
                {
                    cnn.Clone();
                }
            }
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            MySqlConnection cnn = new MySqlConnection(mysqlAddress);
            cnn.Open();
                MySqlCommand cmddisplay = cnn.CreateCommand();
                cmddisplay.CommandText = "select * from tblbarn";
                MySqlDataAdapter adaptable = new MySqlDataAdapter(cmddisplay);
                DataSet ds = new DataSet();
                adaptable.Fill(ds);
                barn.DataSource = ds.Tables[0].DefaultView;
                barn.AutoResizeColumns();
            cnn.Close();


        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            MySqlConnection cnn = new MySqlConnection(mysqlAddress);
            cnn.Open();
            try
            {
                MySqlCommand cmddisplay = cnn.CreateCommand();
                cmddisplay.CommandText = "select * from tblbreeding";
                MySqlDataAdapter adaptable = new MySqlDataAdapter(cmddisplay);
                DataSet ds = new DataSet();
                adaptable.Fill(ds);
                barn.DataSource = ds.Tables[0].DefaultView;
                barn.AutoResizeColumns();
                cnn.Close();
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (cnn.State == ConnectionState.Open)
                {
                    cnn.Clone();
                }
            }
        }

        private void timer6_Tick(object sender, EventArgs e)
        {
            MySqlConnection cnn = new MySqlConnection(mysqlAddress);
            cnn.Open();
            try
            {
                MySqlCommand cmddisplay = cnn.CreateCommand();
                cmddisplay.CommandText = "select * from tblnursery";
                MySqlDataAdapter adaptable = new MySqlDataAdapter(cmddisplay);
                DataSet ds = new DataSet();
                adaptable.Fill(ds);
                barn.DataSource = ds.Tables[0].DefaultView;
                barn.AutoResizeColumns();
                cnn.Close();
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (cnn.State == ConnectionState.Open)
                {
                    cnn.Clone();
                }
            }
        }

        private void timer7_Tick(object sender, EventArgs e)
        {
            MySqlConnection cnn = new MySqlConnection(mysqlAddress);
            cnn.Open();
            try
            {
                MySqlCommand cmddisplay = cnn.CreateCommand();
                cmddisplay.CommandText = "select * from tblgrowing";
                MySqlDataAdapter adaptable = new MySqlDataAdapter(cmddisplay);
                DataSet ds = new DataSet();
                adaptable.Fill(ds);
                barn.DataSource = ds.Tables[0].DefaultView;
                barn.AutoResizeColumns();
                cnn.Close();
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (cnn.State == ConnectionState.Open)
                {
                    cnn.Clone();
                }
            }
        }

        private void bunifuCheckbox1_OnChange(object sender, EventArgs e)
        {
            if (bunifuCheckbox1.Checked == true)
            {
                timer4.Stop();
                timer5.Stop();
                timer6.Stop();
                timer7.Stop();
            }
            else if (bunifuCheckbox1.Checked == false)
            {
                timer4.Start();
                timer5.Start();
                timer6.Start();
                timer7.Start();
            }
        }
    }
}
