﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace HACKATONN
{
    public partial class HistoryMonitoring : Form
    {
        public HistoryMonitoring()
        {
            InitializeComponent();
        }
        String mysqlAddress = "Server = auth-db165.hostinger.ph;port = 3306; database = u396535769_hack;Username = u396535769_hack ; pwd=123456789";
        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            MySqlConnection cnn = new MySqlConnection(mysqlAddress);
            cnn.Open();
            try
            {
                MySqlCommand cmddisplay = cnn.CreateCommand();
                cmddisplay.CommandText = "select * from tbltemperature";
                MySqlDataAdapter adaptable = new MySqlDataAdapter(cmddisplay);
                DataSet ds = new DataSet();
                adaptable.Fill(ds);
                barn.DataSource = ds.Tables[0].DefaultView;
                barn.AutoResizeColumns();
             
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (cnn.State == ConnectionState.Open)
                {
                    cnn.Clone();
                }
            }
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            MySqlConnection cnn = new MySqlConnection(mysqlAddress);
            cnn.Open();
            try
            {
                MySqlCommand cmddisplay = cnn.CreateCommand();
                cmddisplay.CommandText = "select * from tblhumidity";
                MySqlDataAdapter adaptable = new MySqlDataAdapter(cmddisplay);
                DataSet ds = new DataSet();
                adaptable.Fill(ds);
                barn.DataSource = ds.Tables[0].DefaultView;
                barn.AutoResizeColumns();
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (cnn.State == ConnectionState.Open)
                {
                    cnn.Clone();
                }
            }
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            MySqlConnection cnn = new MySqlConnection(mysqlAddress);
            cnn.Open();
            try
            {
                MySqlCommand cmddisplay = cnn.CreateCommand();
                cmddisplay.CommandText = "select * from tblgas";
                MySqlDataAdapter adaptable = new MySqlDataAdapter(cmddisplay);
                DataSet ds = new DataSet();
                adaptable.Fill(ds);
                barn.DataSource = ds.Tables[0].DefaultView;
                barn.AutoResizeColumns();
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (cnn.State == ConnectionState.Open)
                {
                    cnn.Clone();
                }
            }
        }
    }
}
