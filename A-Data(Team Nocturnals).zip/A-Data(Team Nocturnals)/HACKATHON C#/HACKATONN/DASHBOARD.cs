﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HACKATONN
{
    public partial class DASHBOARD : Form
    {
        public DASHBOARD()
        {
            InitializeComponent();
        }
        string a = "1";
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
           
            FARM1 aa = new FARM1();
            aa.Show();
            this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void DASHBOARD_Load(object sender, EventArgs e)
        {
            timer1.Start();
            timer1.Interval = 4000;
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {

            if (a == "1")
            {
                bunifuTransition2.ShowSync(pictureBox4);
                bunifuTransition2.HideSync(pictureBox5);

                a = "2";
                return;
            }
            else if (a == "2")
            {
                bunifuTransition1.ShowSync(pictureBox3);
                bunifuTransition2.HideSync(pictureBox4);

                a = "3";
                return;
            }
            else if (a == "3")
            {
                bunifuTransition2.ShowSync(pictureBox2);
                bunifuTransition2.HideSync(pictureBox3);
                a = "4";
                return;
            }
            else if (a == "4")
            {
                bunifuTransition1.ShowSync(pictureBox5);
                bunifuTransition2.HideSync(pictureBox2);

                a = "1";
                return;
            }
        }
    }
}
