﻿namespace HACKATONN
{
    internal class WindowsMediaPlayer
    {
        internal object control;
        internal object controls;

        public string URL { get; set; }
    }
}